#include "Zombie.hpp"

void	randomChump(std::string name)
{
	Zombie zomb(name, true);
}
